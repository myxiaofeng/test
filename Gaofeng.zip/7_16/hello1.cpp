#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
    cout << "hello world" << endl;
    return 0;
}